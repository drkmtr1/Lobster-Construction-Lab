# B2 integration acceptance and closeout

**Main result:** the mathematics and substantive integration are accepted. A small metadata/replay correction is prepared. No seed experiment or broad research review needs to be repeated.

## What to do

1. Extract this ZIP into a separate folder, outside `Lobster_Construction_Lab`.
2. Read `ACCEPTANCE_REPORT.md` for the findings.
3. Give `OPENCHAMBER_CLOSEOUT_PROMPT.md` to OpenChamber (or Codex) in the existing project, together with this extracted folder's path.
4. The agent inspects/applies `corrections/closeout.patch`, runs the new custody check once, records the local closeout and stops.

The ZIP has its files directly at its root, so normal Windows Extract All places this README directly inside the extraction folder. It is not a replacement repository. Do not copy the entire folder over your project.

## Contents

| Path | Purpose |
|---|---|
| `ACCEPTANCE_REPORT.md` | Complete verdict, evidence, precise corrections and research limits |
| `OPENCHAMBER_CLOSEOUT_PROMPT.md` | One bounded local closeout task |
| `corrections/closeout.patch` | Ten targeted changes based on checkpoint 5fb2fa1 |
| `corrections/verify_preserved_b2_evidence.py` | Standalone copy of the new portable custody checker also included in the patch |
| `proposed/` | The proposed file contents for inspection; applying the patch is preferred |
| `analysis/` | Separate mathematical/evidence/Git reviews, audited metadata and preserved K=1 certificate |
| `replay/` | Observed historical-checker replay result and provenance, with historical files unchanged |
| `validation/` | Corrected-custody success, stale-path/tamper/overwrite checks, and summary |
| `input/` | Exact current uploaded ZIP and preceding returned review ZIP |
| `MANIFEST.json` | Raw-byte hashes of this closeout pack |

All provided source files and the actual user checkout remain unchanged by this review. The old integration verifier/result and all 21 preserved evidence payloads are preserved by the proposed patch. The new tool uses only Python's standard library, writes only a fresh output and does not run a solver.
