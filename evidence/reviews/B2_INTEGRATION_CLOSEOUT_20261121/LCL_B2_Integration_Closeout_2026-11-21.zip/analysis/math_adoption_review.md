# Mathematical adoption review — checkpoint 5fb2fa1

**Date:** November 21, 2026, Pacific/Honolulu.  
**Role:** independent review of mathematical adoption and research scope.  
**Verdict:** **ACCEPT the substantive mathematical integration. REVISE a narrow small-K status description and sharpness wording when recording acceptance.** No new seed search, successor experiment, or project-source modification was performed.

## 1. What was reviewed

Read the supplied `STATE.md`, `AGENTS.md`, actual `research/B2_UNEQUAL_SEED.md`, `research/B2_INTERFACE_OBSTRUCTION.md`, `FINDINGS.md`, `FAILED_HYPOTHESES.md`, `PROOF_OBLIGATIONS.md`, `DECISIONS.md`, and `NEXT_TASK.md`. Compared the adopted theorem with the preceding review pack and the seed note with its previous uploaded version. Read the preserved release's actual positive K=1 pilot certificate to resolve one status inconsistency.

The integrated `research/B2_INTERFACE_OBSTRUCTION.md` ends with the exact original 7,038-byte theorem note, unchanged. Its SHA-256 is `1234e5336d26ffc4aabb17f92e5b64d15aa63e2f9d54f7c8fcd934cc16df8f6f`. The new adoption header clearly identifies the imported body's earlier status text as historical and superseded by provisional integration status.

The seed note differs from its preceding version only by the intended degree-list correction, the identification of the earlier scratch diagnostic, and the new section 9 addendum. Its target, restriction set, argument, run dispositions and conditional transport were preserved.

## 2. Claim-by-claim mathematical decisions

| Claim or change | Verdict | Reason |
|---|---|---|
| p=4 alpha/physical-port seed nonexistence | **ACCEPT** | Difference one forces s:1=3, the actual-edge sum gives a+2b-x=18, and the only three cases all repeat difference four. No extra pin or quotient is used. |
| Conditional all-K high-side shift | **ACCEPT, conditional only** | Every original edge crosses the fixed low/high classes, so shifting high labels adds K to each difference and leaves exactly the required interval and adjacent port. The valid seed does not exist; no supplier follows. |
| Corrected degree description | **ACCEPT** | s:2 is now correctly high-side, degree one, with +4 contribution. The two low leaves are explicitly listed. The sum itself was already correct. |
| Scratch diagnostic disclosure | **ACCEPT** | The earlier y=3-specialized check is identified honestly; the general identity S=a+2b-x-2y+16 is correct. The historical zero-witness enumeration did not depend on that faulty diagnostic. |
| K>=6 interval/adjacent-port obstruction | **ACCEPT** | Extreme labels, both block spans, forced bipartition, compression and both port orientations are sound. Alpha separation is derived, not assumed. |
| Supersession of the unchanged p=5/6/7 repair | **ACCEPT** | The shifted port is K+p rather than K+4; at K=1 its only suffix difference is p-3 rather than one. The historical proposal is preserved and clearly marked unexecuted. |
| Nonadjacent-port consumer as a future candidate | **ACCEPT as a candidate question** | It deliberately relaxes adjacency and explicitly needs a new quantified consumer, a matching supplier and separate K=1 treatment. No existence result is claimed. |
| Blanket status “K=1..5 are undetermined” | **REVISE wording** | The theorem does not settle those cases, but the project already has a verified q=1,r=2,K=1 interface witness. |
| “Threshold sufficient, not sharp” | **REVISE wording where unqualified** | The proof establishes sufficiency. Use “sharpness is not established” or “not claimed sharp”; do not imply a smaller threshold has been proved. |

These reporting corrections do not require another search or a renewed mathematical review cycle. They can be included in the ordinary local acceptance record.

## 3. Independent challenge of the K>=6 argument

The exact full tree has m=K+7 edges and the original prefix has eight vertices and seven edges. If its unused differences are 1..K, the seven prefix differences are K+1..K+7. The maximum difference m requires labels 0,m on prefix vertices. A residual interval of K labels therefore has start 1<=ell<=7.

The eight assigned labels are exactly the two blocks [0,ell-1] and [ell+K,K+7]. Their spans are ell-1 and 7-ell, each at most six. Since every prefix difference is at least K+1>=7, no original edge lies within either block. This forces a proper two-coloring of the connected prefix.

The actual prefix's physical bipartition has four vertices on each side. Therefore both label blocks contain four labels and ell=4. Subtracting K from the upper block preserves label distinctness and subtracts exactly K from each edge difference, yielding an alpha labeling on 0..7 with differences1..7.

For the above port, compression gives s:2=4 in the physical high class, precisely the forbidden seed. For the below port, compression gives s:2=3 in the physical low class. Complementing by 7-g preserves every actual edge difference, exchanges the label classes, and again gives the forbidden physical pin4. The complement is a logical implication between hypothetical witnesses, not an enumeration quotient.

The argument covers any allowable ell, either side, no initial alpha assumption, and no root pin. It is an impossibility of this returned interface, not ordinary nongracefulness, not a statement about another prefix cut, and not a theorem for all unequal q,r. The adopted claims correctly preserve those boundaries.

## 4. Resolve the small-K status using existing evidence

Several new summaries state “K=1..5 are undetermined.” This is too broad as a statement of project knowledge. The original imported theorem body has the more careful wording “It does not determine the interface for K=1,...,5,” and immediately mentions the earlier positive K=1 pilot. A theorem's limited range must not erase a separately verified case.

The preserved source is:

`Lobster_Construction_Lab/evidence/validation/release_final/pilot/cases/31da62597181ea39545cd89689e591113261ea7c9c7af56e60383894da947a57.attempt-0001.json`

Raw SHA-256:

`8c956fd5b770d9e3f3f7d433b5477d981dd6805e9fae5577cb8810bfa5a3a021`.

Its exact case is q=1,r=2,z0=z1=0,K=1,ell=1,above. The saved labeling is:

| Vertex | Label |
|---|---:|
| s:0 | 4 |
| s:1 | 8 |
| s:2 | 2 |
| s:3 | 1 |
| b:0:0 | 6 |
| l:0:0:0 | 3 |
| b:1:0 | 0 |
| l:1:0:0 | 5 |
| l:1:0:1 | 7 |

I checked these existing bytes arithmetically, without rerunning the pilot or searching for a witness. They are bijective onto 0..8; all actual edge differences are exactly1..8. Removing only the suffix vertex s:3 leaves prefix differences2..8, unused labels{1}, unused differences{1}, and the original port s:2=2, immediately above the singleton interval. Thus the old interface is known feasible at K=1.

Recommended replacement:

> The K>=6 argument does not settle smaller K. The preserved q=1,r=2,K=1,ell=1 above-side pilot supplies a verified interface; K=2..5 are not adjudicated here. The threshold6 is sufficient; sharpness is not established.

Apply this clarification to the new summaries in `STATE.md`, the adoption header of `B2_INTERFACE_OBSTRUCTION.md`, `FINDINGS.md` section6, failure entry F-INTERFACE-K6, `PROOF_OBLIGATIONS.md` section5, and the new seed-note addendum. Preserve the imported historical theorem body unchanged; its wording is already qualified.

## 5. Future candidate assessed without executing it

The proposed consumer uses remaining labels [ell,ell+K-1], remaining differences1..K, and endpointell+K+1. This is two above the interval's upper endpoint. It changes exactly the adjacency requirement while retaining the physical path and the resource inventories.

At K=1 it is impossible: the only edge has difference2. Thus the proposed K-domain beginning atK>=2 and a separately justified K=1 branch are appropriate explicit boundaries. This is only a necessary scope restriction; it does not establish a consumer for every largerK, nor any matching unequal-prefix supplier. `NEXT_TASK.md` correctly keeps those duties unproved and the candidate unexecuted.

A later task should first state its quantified hypothesis, range condition within the global alphabet, exact port and path, preservation of the prefix, label/difference partitions, and termination proof. It should not promote a successful finite seed into an all-K supplier without that continuation result. No such successor task was undertaken in this review.

## 6. Remaining duty and stopping point

The mathematical adoption can be accepted with the two small status clarifications recorded. There is no substantive proof defect requiring a new search or rejection of checkpoint5fb2fa1. Local Git acceptance and evidence custody are separate review responsibilities; this note does not certify the live Windows checkout or alter it.

The broader constructive duty is an independently supplied revised interface with a proved consumer. The current bounded review should end after recording acceptance and its limited corrections, leaving that successor as a separately scoped question.
