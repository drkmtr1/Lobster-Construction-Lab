# Evidence custody and verification review — integration checkpoint 5fb2fa1

## Verdict

**ACCEPT the substantive evidence preservation and identity checks. REVISE the raw-manifest path metadata and make replay scope explicit.** No mismatch in the historical seed records, copied review artifacts, configurations, input restrictions, graph identity, or preserved source inventory was found. These findings do not require repeating the seed research or reopening the mathematical proof.

This review inspected the uploaded snapshot and the preserved earlier review/source bytes. It did not access Will's live Windows filesystem or execute the integration verifier. The parent reviewer owns a separate isolated execution of that verifier. This audit writes only its own analysis files and preserves all supplied evidence unchanged.

## Checks actually performed

The read-only audit is reproducible using `analysis/audit_integration_evidence.py`. Its full output is `analysis/integration_evidence_audit.json`.

- The uploaded archive SHA-256 is `38d34f9426a8e84a3a05c21e3714e8800ebecb32fbc2f461bf276f7af6a9e096`.
- Every one of the 58 files listed in the collection's `SHA256_MANIFEST.csv` matches its raw-byte SHA-256. The separately created `MISSING_FILES.txt` is empty; it and the manifest itself are outside that generated list.
- Both historical records in curated `raw/runs/` are byte-identical to the corresponding original `runs/` files in this upload and to the earlier review's original records.
- Both canonical `record_sha256` fields recompute exactly after omission of their self fields. Both copied `config.json` objects equal the corresponding record's embedded config, and their canonical hashes match `config_sha256`.
- All four curated input files match the current uploaded examples/configuration and the earlier reviewed bytes.
- All 13 files copied under `pack/` are byte-identical to the corresponding earlier independent review-pack files. There is no silent alteration of the original proof or review notes.
- All 55 entries in the original full review-pack manifest match the previously delivered ZIP, and its file set matches those entries plus `MANIFEST.json`. This is a check of the complete original deliverable, distinct from the smaller 13-file integrated `pack/` subset.
- Both source inventories recompute and agree. Every inventoried file matches the preserved release source and the preceding review's source snapshot: **15 Python files under `lcl/`, plus six requirements/package files, 21 total**. Describing this as “21 `lcl/` source files” is imprecise; it is not evidence of a code change.
- The graph digests recompute to `9198e106ce33d9b83b8044e385b1599cfe26cd1fe471f4eec841a461868756b2`.
- The new integration verifier's actual SHA-256 matches the value recorded in `verification_result.json`: `448d9bfb3f2d535ff0686a280651ccd811a16268044de8c707c8ef39033fd3b3`.
- The retained earlier independent check script matches its result's recorded script hash. Its saved 144-row result is unchanged. Counting its already-saved sum fields gives 22 assignments with edge sum 28, consistent with the new verifier's H2 detail. This includes all low-label placements; it is not the six candidates remaining after additionally imposing `h(s:1)=3`.

## One concrete manifest repair

`RAW_FILE_MANIFEST.json` contains correct sizes and hashes but stale path prefixes:

| Listed prefix | Actual directory |
|---|---|
| `runs-and-inputs/` | `raw/` |
| `review-pack/` | `pack/` |

None of its 21 literal preserved-file paths exists relative to the evidence directory. After this exact prefix mapping, **all 21 entries match both size and hash**. The two keys under `canonical_record_fields` need the same mapping.

This is a path-metadata error, not missing or changed evidence. Correct the paths in a new local review commit while preserving the historical manifest in Git. Do not rewrite the original records or regenerate their canonical hashes. A future custody verifier should resolve every listed relative path directly and fail if the path is absent.

## What “33/33 passed” actually means

The supplied verification result contains 33 entries with `pass=true`, matching the inspected script's structure:

| Group | Entries | Actual operation |
|---|---:|---|
| A | 7 | Compare original local runs, four input files and the Temp scratch with the external complete review pack |
| B | 10 | Eight comparisons against known raw hashes, plus two informational raw config hashes |
| C | 2 | Validate canonical historical record hashes |
| D | 2 | Validate the contents of both config objects against their canonical hashes |
| E | 3 | Validate the 21-file inventory and compare original local source to the external source snapshot |
| F | 2 | Validate all 55 entries and the file set of the external complete pack |
| G | 3 | Rebuild the named graph using the recorded project builder and compare both embedded original graphs |
| H | 4 | Independently enumerate the same 144 restricted seed assignments and check its counters/general sum identity |

B3 and B4 explicitly call `record(..., True, raw_hash)`: they are successful observations of raw config hashes, not independent pass/fail identity comparisons. This is disclosed in their descriptions and README. D1 and D2 genuinely validate the config contents, so this distinction does not create a substantive evidence gap. The most precise description is **31 predicate checks and two recorded hash observations**, or “33 successful verification entries, including two informational hash entries.”

The graph checks use the project's builder, so they are not wholly independent of it. The H enumeration supplies its own explicit seven-edge list and does not call the project's DFS, oracle or constructor. Its labeling domain and graceful condition are correctly implemented, and its loops cover exactly `4! * 3! = 144` named assignments without a symmetry quotient.

## Replay and custody limits of the new script

`verify_b2_review_pack.py` is a sound task-specific verification script for its supplied inputs, but it is not yet a portable checker for the curated evidence directory itself:

1. It reads original root-level `runs/` paths, not the preserved `raw/runs/` copies.
2. It reads the external full Downloads pack, not the integrated `pack/` subset. The latter deliberately contains only 13 files while its historical manifest describes the original 55-file payload.
3. `SCRATCH_LOCAL` is a hard-coded Windows Temp path. Passing a different `pack_root` does not replace this dependency.
4. It does not validate `RAW_FILE_MANIFEST.json`, which is why the stale prefixes were not detected in its 33 entries.
5. It overwrites the historical `verification_result.json` on replay. The README warns about that behavior, but a new checker should require a fresh output path and refuse overwriting prior evidence.

These limitations are sufficient reason to add a small portable custody check or document an exact recovery procedure. They are not a reason to re-run the original scientific task or demand another broad review loop. The actual curated bytes have now been checked independently by this audit.

The README's omitted-content explanation is broader than the script establishes: it says the omitted `supplied/` tree consists of the project's own tracked files. That earlier 21-file tree also contained Git exports and formerly ignored historical run records. A1–A7 checks only the two records, four inputs and scratch; E1–E3 concerns the separate source inventory. Prefer precise wording that the repository preserves the substantive run/input evidence and selected review artifacts, while the complete earlier pack remains the archive source. Its contents can also be reconstructed from known historical commits where available; do not imply all 21 files were tracked at checkpoint 0f0a39c.

## Minor code-comment correction

The H-loop correctly evaluates

`S = a + 2*b - x - 2*y + 16`.

Its explanatory comment says `x+u+v=3-y`; before imposing `y=3`, the correct equation is `x+u+v=6-y`, since the four low labels sum to six. The executed formula is correct, and the full enumeration is unaffected.

Keep the historical script version whose hash is recorded by the original output. If a new verifier version corrects this comment or changes paths/output behavior, identify it as a new version with a separate result; do not silently rewrite the script and retain an old result claiming its former hash describes the new bytes.

## Acceptance boundary

The evidence-copy objective has been substantively achieved. The original records and reviewed arguments are intact, configurations and graph identity agree, and there is no indication of an altered mathematical target or weakened checker. The only concrete acceptance cleanup from this audit is the manifest's path metadata and accurate replay/reporting descriptions. The parent review handles Git tracking, adoption language, mathematical scope and the final one-next-action decision.
