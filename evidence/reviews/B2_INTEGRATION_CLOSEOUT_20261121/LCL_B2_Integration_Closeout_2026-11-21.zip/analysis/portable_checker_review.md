# Focused review of the portable evidence checker and correction patch

## Disposition

**ACCEPT the portable checker for the declared, reviewed snapshot and the proposed manifest corrections.** No blocking false-acceptance, project-source execution, input-overwrite, or hidden mathematical-claim issue was found. One small extension to the scoped line-ending rules is recommended below for historical-script durability across future checkouts.

Reviewed file: `corrections/verify_preserved_b2_evidence.py`. Its raw SHA-256 at review is `7d5987a9433491c95a3836f8756c61aa97c2304d9ce4276f619924a24b462af4`, which matches the script identity in the observed `validation/corrected_custody_result.json`.

## Code and scope findings

- The checker imports only Python standard-library modules. It does not import the project, the original verifier, the mathematical constructors, or any solver; source-file inspection consists of reading bytes and comparing hashes. The declared directory contains no shadow modules for these imports.
- It anchors both canonical records to the previously accepted canonical hashes and anchors the shared 21-file source inventory to its known digest. Consequently its graph/status inspection does not silently accept a different record merely because its self-hash was recomputed.
- It validates all 21 actual preserved payload paths, sizes, hashes and the exact local raw/pack file set. It additionally checks the 12 copied pack payloads other than the archived manifest against that original manifest. This correctly distinguishes the selected local subset from the complete original package.
- The corrected manifest changes all 21 obsolete paths and both canonical-record keys to `raw/` and `pack/`. Payload sizes and hashes remain unchanged. The patch adds an explanatory correction note and distinguishes the two original archive identities.
- `member()` rejects absolute paths, parent traversal, drive/colon paths and backslash ambiguity, resolves the path, and requires it to stay within its supplied root. No source or artifact path in the declared snapshot escapes that boundary.
- The output path is required, resolved, rejected if it exists, and barred from the preserved raw/pack directories. The final write uses exclusive `xb` creation, so even an intervening appearance of a file causes failure rather than overwrite. The only mutations are creation of the explicitly requested new output and any missing parent directories for it.
- The tool verifies saved experimental facts and identities; it performs no new labeling enumeration. Its result explicitly disclaims proof acceptance. This is a custody check, not an additional negative experiment or independent theorem certificate.
- The historical script and historical output remain unchanged. Its known comment error is documented in the README instead of silently changing the file whose identity appears in the old result.

The checker is deliberately tied to this reviewed evidence set and source snapshot. A future legitimate algorithm version should produce a distinct declared source/run identity; it should not be made to pass this historical identity check by weakening comparisons.

## Observed validation reviewed

The parent supplied focused validation in `validation/VALIDATION_SUMMARY.json` and its associated results:

- The uncorrected snapshot fails because its manifest paths and declared line-ending protection are wrong or absent.
- The corrected snapshot passes **72/72 checks**.
- Appending one newline to a raw evidence file is rejected by its raw-byte hash check, even though the parsed JSON is unchanged.
- Requesting an existing output is refused with exit status 2.
- The patch applies with `core.autocrlf=true`, and all 21 preserved payloads remain byte-identical.

I checked that the result identifies the reviewed script version. The validation project's current new-script copy differs only by LF-to-CRLF conversion; its normalized source is identical. The recorded result matches the proposal's raw source hash, so these two byte representations are not being conflated. I did not broaden or rerun the parent's tests.

## Small line-ending durability recommendation

The proposed evidence-local `.gitattributes` protects `raw/**` and `pack/**`, which is correct for the 21 manifest payloads. The new checker also validates the raw hash of the historical `verify_b2_review_pack.py`, which sits outside those two directories. Its current fixture bytes remain LF and match the recorded hash, but a future autocrlf checkout could convert this unprotected historical file.

Add the exact evidence-local rule `verify_b2_review_pack.py -text`; also preserving `verification_result.json -text` would retain that historical output's bytes consistently. This needs no change to the project's general source line-ending policy. The issue is future preservation of the historical file, not an error in the present mathematical records or a false pass of the current checker.

The checker labels its `.gitattributes` predicate `scoped_eol_rules_declared`: it checks declaration, not arbitrary effective Git configuration. The parent's separate Git validation supplies the relevant behavior check for this patch.
