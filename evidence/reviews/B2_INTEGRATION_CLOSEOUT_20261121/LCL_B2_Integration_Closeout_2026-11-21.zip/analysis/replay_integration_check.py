"""Replay the inspected historical integration checker in an isolated copy.

Only path globals are redirected. The supplied script and historical output
remain byte-identical. This reproduces checker behavior on archived inputs and
hash-matched source, not a live verification of the user's Windows checkout.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import runpy
import shutil
import sys
from zipfile import ZipFile


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--supplied", required=True, type=Path)
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--pack-zip", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    supplied = args.supplied.resolve()
    evidence = supplied / "evidence/reviews/B2_UNEQUAL_SEED_001"
    script = evidence / "verify_b2_review_pack.py"
    historical_result = evidence / "verification_result.json"
    before = {
        str(p): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in (script, historical_result)
    }
    historical = json.loads(historical_result.read_text(encoding="utf-8-sig"))
    assert before[str(script)] == historical["script_sha256"]

    with ZipFile(args.pack_zip) as archive:
        for member in archive.infolist():
            name = member.filename.replace("\\", "/")
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or ":" in name:
                raise ValueError("Unsafe review-pack path")
            destination = out / "pack" / path
            if name.endswith("/"):
                destination.mkdir(parents=True, exist_ok=True)
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(archive.read(member))
    pack_root = out / "pack/LCL_B2_Independent_Review"
    project = out / "project"
    source_record = json.loads((evidence / "raw/runs/dfs-20261121T081441Z-0a3c9a64/record.json").read_text())
    for name, expected in source_record["source"]["files"].items():
        data = (args.source / name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, name
        dest = project / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    for item in (evidence / "raw").rglob("*"):
        if item.is_file():
            dest = project / item.relative_to(evidence / "raw")
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(item, dest)

    namespace = runpy.run_path(str(script), run_name="historical_checker_loaded_for_review")
    main_function = namespace["main"]
    globals_used = main_function.__globals__
    globals_used["PROJECT_ROOT"] = project
    globals_used["SCRATCH_LOCAL"] = pack_root / "supplied/b2_review_scratch.py"
    globals_used["RESULT_PATH"] = out / "portable_verification_result.json"
    sys.path.insert(0, str(project))
    sys.dont_write_bytecode = True
    sys.argv = [str(script), str(pack_root)]
    exit_code = main_function()
    result = json.loads((out / "portable_verification_result.json").read_text())
    for p in (script, historical_result):
        assert hashlib.sha256(p.read_bytes()).hexdigest() == before[str(p)]
    for c in result["checks"]:
        old = next(x for x in historical["checks"] if x["id"] == c["id"])
        assert c["pass"] == old["pass"], c["id"]
    provenance = {
        "scope": "Historical checker replay on isolated archived inputs; no live Windows checkout access.",
        "historical_script_sha256": before[str(script)],
        "historical_result_sha256": before[str(historical_result)],
        "historical_artifacts_unchanged": True,
        "only_runtime_overrides": ["PROJECT_ROOT", "SCRATCH_LOCAL", "RESULT_PATH", "pack_root argv", "sys.path"],
        "source_files_matched": len(source_record["source"]["files"]),
        "result_summary": result["summary"],
        "predicate_checks": 31,
        "informational_entries": ["B3", "B4"],
        "exit_code": exit_code,
        "no_successor_research": True,
    }
    (out / "REPLAY_PROVENANCE.json").write_text(json.dumps(provenance, indent=2) + "\n")
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
