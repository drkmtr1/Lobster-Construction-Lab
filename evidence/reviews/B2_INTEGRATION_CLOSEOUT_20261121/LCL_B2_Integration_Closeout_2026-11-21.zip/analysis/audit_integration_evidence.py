"""Read-only evidence audit; no project imports, solver calls, or new cases."""
from pathlib import Path
from zipfile import ZipFile
import csv
import hashlib
import json

ROOT = Path('/workspace/scratch/77b4e42b77ac')
SUPPLIED = ROOT / 'b2_integration_acceptance/supplied'
EVIDENCE = SUPPLIED / 'evidence/reviews/B2_UNEQUAL_SEED_001'
OLD = ROOT / 'b2_acceptance_review'
SOURCE = ROOT / 'Lobster_Construction_Lab'
OUTPUT = ROOT / 'b2_integration_acceptance/analysis'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def digest(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=False, allow_nan=False).encode())


audit = {'scope': 'Independent artifact-byte audit; no solver or successor search executed.'}
audit['input_archive_sha256'] = sha((ROOT / 'upload/LCL_Codex_Acceptance_Review.zip').read_bytes())
raw_manifest = read(EVIDENCE / 'RAW_FILE_MANIFEST.json')
raw_entries = []
for old_path, expected in raw_manifest['preserved_files'].items():
    if old_path.startswith('runs-and-inputs/'):
        mapped = 'raw/' + old_path.removeprefix('runs-and-inputs/')
    elif old_path.startswith('review-pack/'):
        mapped = 'pack/' + old_path.removeprefix('review-pack/')
    else:
        mapped = old_path
    actual = EVIDENCE / mapped
    data = actual.read_bytes()
    raw_entries.append({
        'listed_path': old_path, 'listed_path_exists': (EVIDENCE / old_path).is_file(),
        'mapped_actual_path': mapped, 'bytes': len(data), 'raw_sha256': sha(data),
        'matches_recorded_size_and_hash': len(data) == expected['bytes'] and sha(data) == expected['raw_file_sha256'],
    })
audit['curated_raw_manifest'] = {
    'entries': raw_entries,
    'literal_paths_existing': sum(e['listed_path_exists'] for e in raw_entries),
    'mapped_entries_matching': sum(e['matches_recorded_size_and_hash'] for e in raw_entries),
    'required_path_correction': {'runs-and-inputs/': 'raw/', 'review-pack/': 'pack/'},
}

pack_copies = []
for path in sorted((EVIDENCE / 'pack').rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(EVIDENCE / 'pack').as_posix()
    old = OLD / relative
    pack_copies.append({'path': relative, 'sha256': sha(path.read_bytes()),
                        'matches_original_review_pack': old.is_file() and path.read_bytes() == old.read_bytes()})
audit['copied_pack_files'] = pack_copies

pack_manifest = read(EVIDENCE / 'pack/MANIFEST.json')
with ZipFile(ROOT / 'deliverables/LCL_B2_Independent_Review_2026-11-21.zip') as z:
    prefix = 'LCL_B2_Independent_Review/'
    actual_names = {n.removeprefix(prefix) for n in z.namelist() if not n.endswith('/')}
    manifest_checks = []
    for relative, expected in pack_manifest['files'].items():
        data = z.read(prefix + relative)
        manifest_checks.append({'path': relative, 'matches': len(data) == expected['bytes'] and sha(data) == expected['sha256']})
    audit['original_complete_pack_manifest'] = {
        'entries': manifest_checks,
        'count': len(manifest_checks),
        'all_match': all(v['matches'] for v in manifest_checks),
        'file_set_matches_including_manifest': actual_names == set(pack_manifest['files']) | {'MANIFEST.json'},
        'original_upload_zip_sha256': sha(z.read(prefix + 'original_upload.zip')),
    }

records = []
for run in ['dfs-20261121T081441Z-0a3c9a64', 'oracle-20261121T081441Z-a5f3c783']:
    relative = f'runs/{run}/record.json'
    raw = EVIDENCE / 'raw' / relative
    data = raw.read_bytes()
    rec = read(raw)
    cfg_path = EVIDENCE / 'raw/runs' / run / 'config.json'
    cfg = read(cfg_path)
    graph = rec['original_graph']
    graph_payload = {'vertices': sorted(graph['vertices']),
                     'edges': sorted(sorted(e) for e in graph['edges'])}
    graph_payload.update({k: graph[k] for k in ('profile', 'spine', 'roles')})
    source_checks = []
    for path, expected in rec['source']['files'].items():
        source_checks.append({'path': path, 'matches': sha((SOURCE / path).read_bytes()) == expected,
                              'matches_previous_review_snapshot': (SOURCE / path).read_bytes() == (OLD / 'source_snapshot' / path).read_bytes()})
    records.append({
        'run': run, 'raw_sha256': sha(data),
        'matches_uploaded_original_run': data == (SUPPLIED / relative).read_bytes(),
        'matches_previous_review_run': data == (OLD / 'supplied' / relative).read_bytes(),
        'canonical_record_sha256': digest({k: v for k, v in rec.items() if k != 'record_sha256'}),
        'canonical_record_hash_matches': digest({k: v for k, v in rec.items() if k != 'record_sha256'}) == rec['record_sha256'],
        'raw_config_sha256': sha(cfg_path.read_bytes()),
        'config_object_matches_embedded_config': cfg == rec['config'],
        'canonical_config_hash_matches': digest(cfg) == rec['config_sha256'],
        'source_inventory_digest_matches': digest(rec['source']['files']) == rec['source']['sha256'],
        'source_files': source_checks,
        'source_python_file_count': sum(p.startswith('lcl/') and p.endswith('.py') for p in rec['source']['files']),
        'source_other_file_count': sum(not p.startswith('lcl/') for p in rec['source']['files']),
        'graph_digest_recomputed': digest(graph_payload),
        'graph_digest_matches': digest(graph_payload) == rec['original_graph_digest'],
        'reported_status': rec['result']['status'],
        'reported_exhausted': rec['result']['exhausted'],
        'reported_count': rec['result']['count'],
    })
audit['records'] = records

inputs = []
for relative in ['examples/unequal_seed.json', 'examples/unequal_seed_pins.json',
                 'examples/unequal_seed_domains.json', 'configs/unequal_seed_limits.json']:
    data = (EVIDENCE / 'raw' / relative).read_bytes()
    inputs.append({'path': relative, 'raw_sha256': sha(data),
                   'matches_current_uploaded_input': data == (SUPPLIED / relative).read_bytes(),
                   'matches_previous_review_input': data == (OLD / 'supplied' / relative).read_bytes()})
audit['inputs'] = inputs

observed = read(EVIDENCE / 'verification_result.json')
script_data = (EVIDENCE / 'verify_b2_review_pack.py').read_bytes()
prior_independent = read(EVIDENCE / 'pack/independent_seed_check.json')
audit['integration_verification_record'] = {
    'summary': observed['summary'],
    'check_count': len(observed['checks']),
    'all_recorded_pass_values_true': all(c['pass'] for c in observed['checks']),
    'script_sha256_recomputed': sha(script_data),
    'script_hash_matches_record': sha(script_data) == observed['script_sha256'],
    'report_only_entries': ['B3', 'B4'],
    'assertion_entry_count': len(observed['checks']) - 2,
    'environment_as_reported': observed['environment'],
    'copied_prior_independent_check_script_hash_matches': sha((EVIDENCE / 'pack/independent_seed_check.py').read_bytes()) == prior_independent['script_sha256'],
    'copied_prior_independent_result_rows': len(prior_independent['all_named_assignments']),
    'saved_rows_sum_28': sum(r['sum'] == 28 for r in prior_independent['all_named_assignments']),
    'script_review': [
        'B3 and B4 intentionally report raw config hashes with pass=True; D1 and D2 actually validate canonical config content.',
        'The checker verifies original root runs and an external complete download pack; it does not directly verify newly curated raw/pack copies or RAW_FILE_MANIFEST.',
        'SCRATCH_LOCAL is a hard-coded Windows temporary path even when a pack_root argument is given.',
        'RESULT_PATH is historical verification_result.json; a replay overwrites it.',
        'Enumeration implements the correct general identity, but its comment says x+u+v=3-y; the correct unrestricted total is 6-y.',
    ],
}

with (SUPPLIED / 'SHA256_MANIFEST.csv').open(encoding='utf-8-sig', newline='') as f:
    outer_manifest = list(csv.DictReader(f))
outer_checks = []
for entry in outer_manifest:
    relative = entry['RelativePath'].replace('\\', '/')
    path = SUPPLIED / relative
    outer_checks.append({'path': relative, 'matches': path.is_file() and sha(path.read_bytes()).lower() == entry['SHA256'].lower()})
audit['uploaded_collection_manifest'] = {'entries': outer_checks, 'all_match': all(c['matches'] for c in outer_checks)}

audit['limitations'] = [
    'The integration checker was inspected, not executed; no supplied evidence was overwritten.',
    'Current Windows filesystem, actual Git objects, external Downloads and Temp paths were not accessed.',
    'Source validation uses previously preserved release bytes, matched to both recorded source inventories.',
]

OUTPUT.mkdir(parents=True, exist_ok=True)
(OUTPUT / 'integration_evidence_audit.json').write_text(json.dumps(audit, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps({
    'curated_manifest_literal_paths_found': audit['curated_raw_manifest']['literal_paths_existing'],
    'curated_manifest_entries_valid_after_prefix_mapping': audit['curated_raw_manifest']['mapped_entries_matching'],
    'copied_pack_files': len(pack_copies),
    'copied_pack_matches': all(p['matches_original_review_pack'] for p in pack_copies),
    'complete_original_manifest_entries': audit['original_complete_pack_manifest']['count'],
    'complete_original_manifest_matches': audit['original_complete_pack_manifest']['all_match'],
    'verification_script_hash_matches': audit['integration_verification_record']['script_hash_matches_record'],
    'collection_manifest_all_match': audit['uploaded_collection_manifest']['all_match'],
    'lcl_python_files': records[0]['source_python_file_count'],
    'other_inventory_files': records[0]['source_other_file_count'],
}, indent=2))
