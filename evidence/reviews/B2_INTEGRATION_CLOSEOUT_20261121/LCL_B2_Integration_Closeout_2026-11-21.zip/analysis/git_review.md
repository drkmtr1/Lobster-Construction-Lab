# Git, handoff overlay, and evidence-checkout review

## Verdict

**ACCEPT the content and scope of the exported checkpoint, the root-only `runs` ignore fix, and the bounded handoff overlay. REVISE the evidence checkout policy with a small scoped `.gitattributes` addition.** No source corruption or missing historical record was found. The current raw and imported pack bytes are intact. No mathematical solver was run and no supplied or original project file was modified during this audit.

## Checkpoint scope independently reconstructed

The exports identify:

- Baseline: `36ea1603602491bf3c1c5b81ed4c23aaa2210e70`.
- Handoff overlay: `6d0f8d23f4f0d9f1d4440f4bfa7a7c5f25051685`.
- Seed checkpoint: `0f0a39c4d8d97d211782d1a1d81aeba5e0481319`.
- Current integration: `5fb2fa108835720c829cafd5095983f3c0f6198d`.

The latest integration patch contains exactly **35 files, 7,408 insertions, and 14 deletions**, matching the Owner report. The complete baseline-to-current patch contains **44 files, 7,835 insertions, and 28 deletions**. Every old blob prefix matches the appropriate preserved preimage, every new blob prefix matches the reconstructed result, and every supplied postimage matches that result after ordinary Git line-ending normalization where required.

Only `RAW_FILE_MANIFEST.json` and `verification_result.json` have CRLF working-copy bytes with LF Git blobs. All eight files under curated `raw/` and all thirteen under curated `pack/` are currently **byte-identical** to their Git blobs. These 21 preserved files are included among the 25 tracked curated evidence files. Both historical records and their two run configuration files are present in the tracked inventory and patches. The original root `runs/` records are not tracked, as intended.

The patches contain no changes to `lcl/`, tests, original target input, original seed pin/domain inputs, or original solver configuration. A new evidence-verification Python script was added under `evidence/reviews/`; this is verification tooling, so the report's broad phrase “no code changed” should be understood as no solver/constructor/checker-core change. The new verification code is audited separately.

## Export encoding was recovered completely

Both PowerShell-produced patches repeat the earlier reversible character corruption: Git UTF-8 output was apparently decoded through CP437 before being saved as UTF-8. There are no Unicode replacement characters. Removing the BOM, normalizing exported CRLF, then reversing that decoding recovers valid UTF-8 patches. The reconstructed blob checks above establish successful recovery.

Recovered files are `full-diff-since-baseline.normalized.patch` and `latest-integration.normalized.patch`. Raw uploaded exports remain untouched. No re-upload is necessary. A future collection command can use Git's direct `--output` option rather than a native-output text pipeline, but this is not a reason to repeat the current collection.

## The ignore fix is correct

The exact change is `runs/` to `/runs/` in the root ignore file. The unanchored rule matched nested curated directories named `runs`; the anchored rule keeps excluding root runtime output while allowing curated evidence under `evidence/reviews/.../raw/runs/`.

A small isolated Git check with the supplied ignore file confirmed:

- `runs/example/record.json` is ignored.
- The curated historical-record path is not ignored.
- `.venv/example.txt` remains ignored.

No global or user-project Git settings were changed.

## One remaining custody correction: protect byte-preserved evidence from EOL conversion

The exported tracked-file list contains no `.gitattributes`. Thus the current byte hashes are correct, but no versioned rule protects these snapshots against text conversion during a later Windows checkout.

This is a demonstrated portability issue, not an assertion about the user's current `core.autocrlf` value. In an isolated temporary Git repository, with `core.autocrlf=true` explicitly set only for the test:

1. The actual historical record and imported pack README both changed from LF to CRLF on checkout without attributes, changing their raw hashes.
2. With the following scoped attributes, both checked out byte-identically:

```text
# evidence/reviews/B2_UNEQUAL_SEED_001/.gitattributes
raw/** -text
pack/** -text
```

The recommended fix disables text normalization only for the immutable reviewed payloads. It does not change global Git configuration, active source conventions, or old run files. Current blobs are already byte-identical to the accepted snapshots, so historical commits need not be rewritten. Inspect and verify the next local commit's reviewed payload hashes and perform one focused clean-checkout comparison.

The complete test result is in `git_behavior_check.json`. The test was confined to newly created scratch data; no project files were touched.

## Handoff overlay review

The complete patch includes the formerly unaccepted overlay. Two skills and the first-session prompt were not copied directly by the collection script, but their complete contents were recoverable as new-file patch entries and their blob prefixes verified. Recovered copies are under `reconstructed_overlay/`.

The overlay's instructions are coherent with the project: exact original topology and declared restrictions, bounded tasks, incomplete-result preservation, immutable evidence, separate review for semantic changes, explicit handoffs, and no automatic successor campaign. It does not change mathematical definitions or the source algorithms. The existing setup/provider instructions are background configuration documentation; this review did not operate or reconfigure OpenChamber.

The skills' capitalized frontmatter names are not an error in OpenCode V2. The current official skill documentation specifies path-derived IDs and display-only frontmatter names; the two directories provide the expected IDs `lcl-bounded-research` and `lcl-handoff`. Source inspected November 21, 2026: https://opencode.ai/docs/skills/ . No skill rewrite is needed for that issue.

## Provenance limits

The bundle contains text exports rather than `.git` objects, refs, or a signed repository bundle. The empty status export and tag/head/history text are consistent with the Owner report, but this audit cannot authenticate live branch state, parent links, annotation type, tag immutability, or absence of a remote push from the user's machine. The patch reconstruction validates exported content against known preimages; it is not verification of commit object hashes.

These limits do not require another general review round. A local closeout can check the live checkout, apply the small evidence-portability correction together with other specific record corrections, record the scoped acceptance of the reviewed snapshot, and proceed according to the next explicit research decision.

## Artifacts

- `git_patch_audit.json`: all 44 baseline and 35 integration entries, blob prefixes, reconstruction hashes, and postimage comparisons.
- `git_export_summary.json`: tracked inventory, evidence counts, reported head/baseline and scope.
- `git_behavior_check.json`: isolated ignore and EOL preservation checks.
- The two normalized patches and the three recovered overlay files.
